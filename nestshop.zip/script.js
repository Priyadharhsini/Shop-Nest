
function swapImg(clickedImg){
    const mainImg = document.getElementById("mainImg");
    if(clickedImg === mainImg) return;
    mainImg.style.opacity=0;
    clickedImg.style.opacity=0;
    const temp = mainImg.src;
    setTimeout(() => {
    mainImg.src=clickedImg.src;
    clickedImg.src=temp;
    mainImg.style.opacity=1;
    clickedImgImg.style.opacity=1;
    clickedImgImg.style.zIndex=999;
},400);
}